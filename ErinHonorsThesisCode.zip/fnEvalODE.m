function eval = fnEvalODE(params, fn, array_names, init_cond, obj_fn)
%% get gradient & hessian 
tspan = [0:1:100];
evalfn = @(p)fn(tspan, init_cond, p);
obj = @(p)obj_fn(evalfn(params),evalfn, p);
gradient = grad_fdm_ODE(struct2array(params,array_names), evalfn,2,[], obj)
hessian = hess_fdm_ODE(struct2array(params,array_names), evalfn, obj)
[V,D] = eig(hessian)
testSVD(hessian)
end